export interface Product {
  product_id: number;
  product_category: string;
  product_name: string;
  unit_price: number;
  image: string;
}
